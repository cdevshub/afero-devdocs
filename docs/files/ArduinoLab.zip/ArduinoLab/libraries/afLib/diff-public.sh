#!/bin/bash

files=`find . -type f \( -name "*.ino" -o -name "*.txt" -o -name "*.cpp" -o -name "*.h" \) -print`
for file in $files
do
	if [ -e ~/src/kmart/firmware/public/afLib/$file ]
	then
		differences=`diff $file ~/src/kmart/firmware/public/afLib/$file`
		if [[ ! -z $differences ]]
		then
			echo File: $file
			diff $file ~/src/kmart/firmware/public/afLib/$file
		fi
	else
		echo "Not found:" $file
	fi
done
#find . -type f \( -name "*.ino" -o -name "*.txt" -o -name "*.cpp" -o -name "*.h" \) -exec diff {} ~/src/kmart/firmware/public/afLib/{} \;
