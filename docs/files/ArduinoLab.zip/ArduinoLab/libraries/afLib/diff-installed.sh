find . -type f \( -name "*.ino" -o -name "*.txt" -o -name "*.cpp" -o -name "*.h" \) -exec diff {} ~/src/arduino/libraries/afLib/{} \;
