/*
 * afLibD21.cpp
 *
 * Created: 6/13/2017 1:32:01 PM
 * Author : zz
 */

/************************************************************************/
/* It appears C++ stuff needs to be included before ASF.  */
/************************************************************************/
#include <iafLib.h>
#include <ArduinoSPI.h>
#include <AtmelLog.h>

#include <asf.h>
#include <delay.h>
#include "stdio_serial.h"
#include "conf_uart_serial.h"
#include "millis.h"
#include "ModuleCommands.h"
#include "ModuleStates.h"
#include "atmel_spi.h"

// Include the constants required to access attribute ids from your profile.
#include "profile/afBlink/device-description.h"

//#define USE_UART                  1
#define USE_SPI                   1
#define BAUD_RATE                 38400

#define RX_PIN                    7
#define TX_PIN                    8

#define INT_PIN                   PIN_PB04A_EIC_EXTINT4
#define CS_PIN                    10
#define RESET                     21    // This is used to reboot the Modulo when the MCU boots

// Need to define these as inputs so they will float and we can connect the real pins for SPI on the
// Zero which are 50 - 52. You need to use jumper wires to connect the pins from the Zero to the Plinto.
// Since the Zero is 5V, you must use a Plinto adapter.
#define MOSI                      11    // 51 on Mega Zero
#define MISO                      12    // 50 on Mega Zero
#define SCK                       13    // 52 on Mega Zero

// Modulo LED is active low
#define LED_OFF                   1
#define LED_ON                    0

// blink the LED every 3 seconds
#define BLINK_INTERVAL            3000

#define ATTR_PRINT_HEADER_LEN     60
#define ATTR_PRINT_MAX_VALUE_LEN  256
#define ATTR_PRINT_BUFFER_LEN     (ATTR_PRINT_HEADER_LEN + ATTR_PRINT_MAX_VALUE_LEN)

/**
 * afLib Stuff
 */
iafLib *aflib;
volatile long lastBlink = 0;
volatile bool blinking = false;
volatile bool moduloLEDIsOn = false;      // Track whether the Modulo LED is on
volatile uint16_t moduleButtonValue = 1;  // Track the button value so we know when it has changed
char attr_print_buffer[ATTR_PRINT_BUFFER_LEN];
static struct usart_module cdc_uart_module;

/**
 * Forward definitions
 */
void toggleModuloLED();
void setModuloLED(bool on);
void printAttribute(const char *label, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value);
bool attrSetHandler(const uint8_t requestId, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value);
void attrNotifyHandler(const uint8_t requestId, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value);

/**
 *  Configure UART console.
 */
static void configure_console(void)
{
	struct usart_config usart_conf;

	usart_get_config_defaults(&usart_conf);
	usart_conf.mux_setting = CONF_STDIO_MUX_SETTING;
	usart_conf.pinmux_pad0 = CONF_STDIO_PINMUX_PAD0;
	usart_conf.pinmux_pad1 = CONF_STDIO_PINMUX_PAD1;
	usart_conf.pinmux_pad2 = CONF_STDIO_PINMUX_PAD2;
	usart_conf.pinmux_pad3 = CONF_STDIO_PINMUX_PAD3;
	usart_conf.baudrate    = CONF_STDIO_BAUDRATE;

	stdio_serial_init(&cdc_uart_module, CONF_STDIO_USART_MODULE, &usart_conf);
	usart_enable(&cdc_uart_module);
}

void loop() {
	if (blinking) {
		if (millis() - lastBlink > BLINK_INTERVAL) {
			toggleModuloLED();
			lastBlink = millis();
		}
		} else {
		setModuloLED(false);
	}

	// Give the afLib state machine some time.
	aflib->loop();
}

// This is called when the service changes one of our attributes.
bool attrSetHandler(const uint8_t requestId, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value) {
    printAttribute("attrSetHandler", attributeId, valueLen, value);

    switch (attributeId) {
        // This MCU attribute tells us whether we should be blinking.
        case AF_BLINK:
            blinking = (*value == 1);
            break;

        default:
            break;
    }

    // Return false here if your hardware was unable to perform the set request from the service.
    // This lets the service know that the value did not change.
    return true;
}

// This is called when either an Afero attribute has been changed via setAttribute or in response
// to a getAttribute call.
void attrNotifyHandler(const uint8_t requestId, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value) {
    printAttribute("attrNotifyHandler", attributeId, valueLen, value);

    switch (attributeId) {
        // Update the state of the LED based on the actual attribute value.
        case AF_MODULO_LED:
            moduloLEDIsOn = (*value == 0);
            break;

            // Allow the button on Modulo to control our blinking state.
        case AF_MODULO_BUTTON: {
            uint16_t *buttonValue = (uint16_t *) value;
            if (moduleButtonValue != *buttonValue) {
                moduleButtonValue = *buttonValue;
                blinking = !blinking;
                if (aflib->setAttributeBool(AF_BLINK, blinking) != afSUCCESS) {
                    printf("Could not set BLINK\r\n");
                }
            }
        }
            break;

        case AF_SYSTEM_ASR_STATE:
            printf("ASR state: ");
            switch (value[0]) {
                case MODULE_STATE_REBOOTED:
                    printf("Rebooted\r\n");
                    break;

                case MODULE_STATE_LINKED:
                    printf("Linked\r\n");
                    break;

                case MODULE_STATE_UPDATING:
                    printf("Updating\r\n");
                    break;

                case MODULE_STATE_UPDATE_READY:
                    printf("Update ready - rebooting\r\n");
                    aflib->setAttribute32(AF_SYSTEM_COMMAND, MODULE_COMMAND_REBOOT);
                    break;

                default:
                    break;
            }
            break;

        default:
            break;
    }
}

void toggleModuloLED() {
    setModuloLED(!moduloLEDIsOn);
}

void setModuloLED(bool on) {
    if (moduloLEDIsOn != on) {
        int16_t attrVal = on ? LED_ON : LED_OFF; // Modulo LED is active low
        while (aflib->setAttribute16(AF_MODULO_LED, attrVal) != afSUCCESS) {
            printf("Could not set LED\r\n");
	        aflib->loop();
        }
        moduloLEDIsOn = on;
    }
}

// Define this wrapper to allow the instance method to be called
// when the interrupt fires. We do this because attachInterrupt
// requires a method with no parameters and the instance method
// has an invisible parameter (this).
void ISRWrapper() {
    if (aflib) {
        aflib->mcuISR();
    }
}

/****************************************************************************************************
 * Debug Functions                                                                                  *
 *                                                                                                  *
 * Some helper functions to make debugging a little easier...                                       *
 ****************************************************************************************************/
void getPrintAttrHeader(const char *sourceLabel, const char *attrLabel, const uint16_t attributeId, const uint16_t valueLen) {
    memset(attr_print_buffer, 0, ATTR_PRINT_BUFFER_LEN);
    snprintf(attr_print_buffer, ATTR_PRINT_BUFFER_LEN, "%s id: %s len: %05d value: ", sourceLabel, attrLabel, valueLen);
}

void printAttrBool(const char *sourceLabel, const char *attrLabel, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value) {
    getPrintAttrHeader(sourceLabel, attrLabel, attributeId, valueLen);
    strcat(attr_print_buffer, *value == 1 ? "true" : "false");
    printf("%s\r\n", attr_print_buffer);
}

void printAttr8(const char *sourceLabel, const char *attrLabel, const uint8_t attributeId, const uint16_t valueLen, const uint8_t *value) {
    getPrintAttrHeader(sourceLabel, attrLabel, attributeId, valueLen);
    char intStr[6];
    strcat(attr_print_buffer, itoa(*((uint8_t *)value), intStr, 10));
    printf("%s\r\n", attr_print_buffer);
}

void printAttr16(const char *sourceLabel, const char *attrLabel, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value) {
    getPrintAttrHeader(sourceLabel, attrLabel, attributeId, valueLen);
    char intStr[6];
    strcat(attr_print_buffer, itoa(*((uint16_t *)value), intStr, 10));
    printf("%s\r\n", attr_print_buffer);
}

void printAttr32(const char *sourceLabel, const char *attrLabel, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value) {
    getPrintAttrHeader(sourceLabel, attrLabel, attributeId, valueLen);
    char intStr[11];
    strcat(attr_print_buffer, itoa(*((uint32_t *)value), intStr, 10));
    printf("%s\r\n", attr_print_buffer);
}

void printAttrHex(const char *sourceLabel, const char *attrLabel, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value) {
    getPrintAttrHeader(sourceLabel, attrLabel, attributeId, valueLen);
    for (int i = 0; i < valueLen; i++) {
        strcat(attr_print_buffer, String(value[i], HEX).c_str());
    }
    printf("%s\r\n", attr_print_buffer);
}

void printAttrStr(const char *sourceLabel, const char *attrLabel, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value) {
    getPrintAttrHeader(sourceLabel, attrLabel, attributeId, valueLen);
    int len = strlen(attr_print_buffer);
    for (int i = 0; i < valueLen; i++) {
        attr_print_buffer[len + i] = (char)value[i];
    }
    printf("%s\r\n", attr_print_buffer);
}

void printAttribute(const char *label, const uint16_t attributeId, const uint16_t valueLen, const uint8_t *value) {
    switch (attributeId) {
        case AF_BLINK:
            printAttrBool(label, "AF_BLINK", attributeId, valueLen, value);
            break;

        case AF_MODULO_LED:
            printAttr16(label, "AF_MODULO_LED", attributeId, valueLen, value);
            break;

        case AF_GPIO_0_CONFIGURATION:
            printAttrHex(label, "AF_GPIO_0_CONFIGURATION", attributeId, valueLen, value);
            break;

        case AF_MODULO_BUTTON:
            printAttr16(label, "AF_MODULO_BUTTON", attributeId, valueLen, value);
            break;

        case AF_GPIO_3_CONFIGURATION:
            printAttrHex(label, "AF_GPIO_3_CONFIGURATION", attributeId, valueLen, value);
            break;

        case AF_BOOTLOADER_VERSION:
            printAttrHex(label, "AF_BOOTLOADER_VERSION", attributeId, valueLen, value);
            break;

        case AF_SOFTDEVICE_VERSION:
            printAttrHex(label, "AF_SOFTDEVICE_VERSION", attributeId, valueLen, value);
            break;

        case AF_APPLICATION_VERSION:
            printAttrHex(label, "AF_APPLICATION_VERSION", attributeId, valueLen, value);
            break;

        case AF_PROFILE_VERSION:
            printAttrHex(label, "AF_PROFILE_VERSION", attributeId, valueLen, value);
            break;

        case AF_SYSTEM_ASR_STATE:
            printAttr8(label, "AF_SYSTEM_ASR_STATE", attributeId, valueLen, value);
            break;

        case AF_SYSTEM_LOW_POWER_WARN:
            printAttr8(label, "AF_ATTRIBUTE_LOW_POWER_WARN", attributeId, valueLen, value);
            break;

        case AF_SYSTEM_REBOOT_REASON:
            printAttrStr(label, "AF_REBOOT_REASON", attributeId, valueLen, value);
            break;

        case AF_SYSTEM_MCU_INTERFACE:
            printAttr8(label, "AF_SYSTEM_MCU_INTERFACE", attributeId, valueLen, value);
            break;

        case AF_SYSTEM_LINKED_TIMESTAMP:
            printAttr32(label, "AF_SYSTEM_LINKED_TIMESTAMP", attributeId, valueLen, value);
            break;
    }
}

void pinMode(uint8_t pin, enum port_pin_dir mode)
{
	struct port_config pin_conf;
	port_get_config_defaults(&pin_conf);

	switch (mode) {
		case PORT_PIN_DIR_INPUT:
			pin_conf.direction  = PORT_PIN_DIR_INPUT;
			port_pin_set_config(pin, &pin_conf);
		break;
		
		case PORT_PIN_DIR_OUTPUT:
			pin_conf.direction  = PORT_PIN_DIR_OUTPUT;
			port_pin_set_config(pin, &pin_conf);
			port_pin_set_output_level(pin, false);
			break;
	}
}

void digitalWrite(uint8_t pin, uint8_t level)
{
	port_pin_set_output_level(pin, level == 0 ? false : true);
}

void setup() {
    printf("Hello World\r\n");

    printf("Using D21 - Resetting Modulo\r\n");

    pinMode(RESET, PORT_PIN_DIR_OUTPUT);
    digitalWrite(RESET, 0);
    delay(250);
    digitalWrite(RESET, 1);
    delay(1000);

	Stream *theLog = new AtmelLog();
    afTransport *arduinoSPI = new ArduinoSPI(CS_PIN, theLog);

    /**
     * Initialize the afLib
     *
     * Just need to configure a few things:
     *  INT_PIN - the pin used slave interrupt
     *  ISRWrapper - function to pass interrupt on to afLib
     *  onAttrSet - the function to be called when one of your attributes has been set.
     *  onAttrSetComplete - the function to be called in response to a getAttribute call or when a afero attribute has been updated.
     *  Serial - class to handle serial communications for debug output.
     *  theSPI - class to handle SPI communications.
     */
    const int int_pin = INT_PIN;

    aflib = iafLib::create(INT_PIN, ISRWrapper, attrSetHandler, attrNotifyHandler, theLog, arduinoSPI);
}

int main(void)
{
    /* Initialize the SAM system */
    SystemInit();
	system_init();
	delay_init();
	config_systick();
	configure_console();
	
	printf("Hello World!\r\n");

	//! [run_config]
	configure_spi_master();
	//! [run_config]
	//! [run_callback_config]
	configure_spi_master_callbacks();
	//! [run_callback_config]
	//! [main_start]
	
	printf("before setup\r\n");
	setup();
	
	printf("before loop\r\n");
	while (true) {
		/* Infinite loop */
		loop();
	}
}
