/*
 * millis.h
 *
 * Created: 6/15/2017 11:03:19 AM
 *  Author: zz
 */ 


#ifndef MILLIS_H_
#define MILLIS_H_

extern "C" {
	void config_systick(void);
	long millis();
};

#endif /* MILLIS_H_ */