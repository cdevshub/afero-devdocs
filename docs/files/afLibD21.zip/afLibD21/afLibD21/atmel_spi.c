/*
 * atmel_spi.c
 *
 * Created: 6/16/2017 8:39:58 AM
 *  Author: zz
 */ 
#include <asf.h>

//! [setup]
//! [buf_length]
#define BUF_LENGTH 20
//! [buf_length]
//! [slave_select_pin]
#define SLAVE_SELECT_PIN CONF_MASTER_SS_PIN
//! [slave_select_pin]
//! [buffer]
static uint8_t wr_buffer[BUF_LENGTH] = {
	0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,
	0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13
};
static uint8_t rd_buffer[BUF_LENGTH];
//! [buffer]

//! [dev_inst]
struct spi_module spi_master_instance;
//! [dev_inst]
//! [slave_dev_inst]
struct spi_slave_inst slave;
//! [slave_dev_inst]
//! [var]
static volatile bool transrev_complete_spi_master = false;
//! [var]
//! [setup]

//! [callback]
static void callback_spi_master( struct spi_module *const module)
{
	//! [callback_var]
	transrev_complete_spi_master = true;
	//! [callback_var]
}
//! [callback]

void spi_begin_transaction(void)
{
	spi_select_slave(&spi_master_instance, &slave, true);
}

void spi_end_transaction(void)
{
	spi_select_slave(&spi_master_instance, &slave, false);
}

void spi_transfer(uint8_t *p_buffer, uint8_t buffer_size)
{
	spi_transceive_buffer_job(&spi_master_instance, p_buffer, p_buffer, buffer_size);
	while (!transrev_complete_spi_master) {
		/////* Wait for write and read complete */
	}
	transrev_complete_spi_master = false;	
}

//! [conf_callback]
void configure_spi_master_callbacks(void)
{
	//! [reg_callback]
	spi_register_callback(&spi_master_instance, callback_spi_master,
	SPI_CALLBACK_BUFFER_TRANSCEIVED);
	//! [reg_callback]
	//! [en_callback]
	spi_enable_callback(&spi_master_instance, SPI_CALLBACK_BUFFER_TRANSCEIVED);
	//! [en_callback]
}
//! [conf_callback]

//! [configure_spi]
void configure_spi_master(void)
{
	//! [config]
	struct spi_config config_spi_master;
	//! [config]
	//! [slave_config]
	struct spi_slave_inst_config slave_dev_config;
	//! [slave_config]
	/* Configure and initialize software device instance of peripheral slave */
	//! [slave_conf_defaults]
	spi_slave_inst_get_config_defaults(&slave_dev_config);
	//! [slave_conf_defaults]
	//! [ss_pin]
	slave_dev_config.ss_pin = SLAVE_SELECT_PIN;
	//! [ss_pin]
	//! [slave_init]
	spi_attach_slave(&slave, &slave_dev_config);
	//! [slave_init]
	/* Configure, initialize and enable SERCOM SPI module */
	//! [conf_defaults]
	spi_get_config_defaults(&config_spi_master);
	//! [conf_defaults]
	//! [mux_setting]
	config_spi_master.mux_setting = CONF_MASTER_MUX_SETTING;
	//! [mux_setting]

	config_spi_master.transfer_mode = SPI_TRANSFER_MODE_0;
	config_spi_master.data_order = SPI_DATA_ORDER_LSB;
	config_spi_master.character_size = SPI_CHARACTER_SIZE_8BIT;
	config_spi_master.pinmux_pad0 = CONF_MASTER_PINMUX_PAD0;
	config_spi_master.pinmux_pad1 = CONF_MASTER_PINMUX_PAD1;
	config_spi_master.pinmux_pad2 = CONF_MASTER_PINMUX_PAD2;
	config_spi_master.pinmux_pad3 = CONF_MASTER_PINMUX_PAD3;

	//! [init]
	spi_init(&spi_master_instance, CONF_MASTER_SPI_MODULE, &config_spi_master);
	//! [init]

	//! [enable]
	spi_enable(&spi_master_instance);
	//! [enable]

}
//! [configure_spi]

