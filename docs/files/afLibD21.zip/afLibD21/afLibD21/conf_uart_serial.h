/*
 * conf_uart_serial.h
 *
 * Created: 6/14/2017 8:21:03 AM
 *  Author: zz
 */ 


#ifndef CONF_UART_SERIAL_H_
#define CONF_UART_SERIAL_H_

#include <board.h>
//! [conf_uart_serial_settings]
#define CONF_STDIO_USART_MODULE  EDBG_CDC_MODULE
#define CONF_STDIO_MUX_SETTING   EDBG_CDC_SERCOM_MUX_SETTING
#define CONF_STDIO_PINMUX_PAD0   EDBG_CDC_SERCOM_PINMUX_PAD0
#define CONF_STDIO_PINMUX_PAD1   EDBG_CDC_SERCOM_PINMUX_PAD1
#define CONF_STDIO_PINMUX_PAD2   EDBG_CDC_SERCOM_PINMUX_PAD2
#define CONF_STDIO_PINMUX_PAD3   EDBG_CDC_SERCOM_PINMUX_PAD3
#define CONF_STDIO_BAUDRATE      38400
//! [conf_uart_serial_settings]

#endif /* CONF_UART_SERIAL_H_ */