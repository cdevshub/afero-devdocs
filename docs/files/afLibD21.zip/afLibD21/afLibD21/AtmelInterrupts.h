/* 
* AtmelInterrupts.h
*
* Created: 6/16/2017 10:37:59 AM
* Author: zz
*/


#ifndef __ATMELINTERRUPTS_H__
#define __ATMELINTERRUPTS_H__

#include <asf.h>

typedef void (*interrupt_handler_t)(void);

class AtmelInterrupts
{
//variables
public:
protected:
private:
	uint32_t interrupt_pin;
	uint32_t interrupt_mux;
	uint8_t interrupt_channel;
	interrupt_handler_t interrupt_handler;

//functions
public:
	AtmelInterrupts(uint32_t pin, interrupt_handler_t interrupt_handler);
	~AtmelInterrupts();
	
protected:
private:
	//atmelinterrupts( const atmelinterrupts &c );
	//atmelinterrupts& operator=( const atmelinterrupts &c );

}; //AtmelInterrupts

#endif //__ATMELINTERRUPTS_H__
