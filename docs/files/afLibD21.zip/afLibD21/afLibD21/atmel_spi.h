/*
 * atmel_spi.h
 *
 * Created: 6/16/2017 8:41:27 AM
 *  Author: zz
 */ 


#ifndef ATMEL_SPI_H_
#define ATMEL_SPI_H_

#include <asf.h>

extern "C" {
	void configure_spi_master_callbacks(void);
	void configure_spi_master(void);
	void spi_begin_transaction(void);
	void spi_end_transaction(void);
	void spi_transfer(uint8_t *p_buffer, uint8_t buffer_size);
};

#endif /* ATMEL_SPI_H_ */