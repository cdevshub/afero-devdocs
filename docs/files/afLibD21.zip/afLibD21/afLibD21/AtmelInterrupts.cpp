/* 
* AtmelInterrupts.cpp
*
* Created: 6/16/2017 10:37:59 AM
* Author: zz
*/

#include "AtmelInterrupts.h"

// default constructor
AtmelInterrupts::AtmelInterrupts(uint32_t pin, interrupt_handler_t interrupt_handler)
{
	struct extint_chan_conf config_extint_chan;
	extint_chan_get_config_defaults(&config_extint_chan);

	interrupt_pin = pin;
	interrupt_handler = interrupt_handler;
	switch(pin) {
		case PIN_PB04A_EIC_EXTINT4:
			interrupt_mux = MUX_PB04A_EIC_EXTINT4;
			interrupt_channel = 4;
			break;
			
		case PIN_PA15A_EIC_EXTINT15:
			interrupt_mux = MUX_PB15A_EIC_EXTINT15;
			interrupt_channel = 15;
			break;
			
		default:
			printf("Error: unsupported INT pin");
			break;
	}

	config_extint_chan.gpio_pin           = pin;
	config_extint_chan.gpio_pin_mux       = interrupt_mux;
	config_extint_chan.gpio_pin_pull      = EXTINT_PULL_DOWN;
	config_extint_chan.detection_criteria = EXTINT_DETECT_FALLING;

	extint_chan_set_config(interrupt_channel, &config_extint_chan);

	extint_register_callback((extint_callback_t)interrupt_handler, interrupt_channel, EXTINT_CALLBACK_TYPE_DETECT);

	extint_chan_enable_callback(interrupt_channel, EXTINT_CALLBACK_TYPE_DETECT);

	system_interrupt_enable_global();
} //AtmelInterrupts

// default destructor
AtmelInterrupts::~AtmelInterrupts()
{
} //~AtmelInterrupts
