/*
 * millis.c
 *
 * Created: 6/15/2017 10:57:26 AM
 *  Author: zz
 */ 

#include <asf.h>

static volatile long milliseconds_since_boot = 0;

void config_systick(void)
{
	// Setup the tick handler so we can get milliseconds.
	// We have to pass constants here because the SysTick_Config definition errors if you try to use functions.
	SysTick_Config(1000000/250);
}

long millis() {
	return milliseconds_since_boot;
}

/**
 * \brief SysTick handler used to measure precise delay. 
 */
void SysTick_Handler(void)
{
	milliseconds_since_boot++;
	//port_pin_toggle_output_level(LED_0_PIN);
}

